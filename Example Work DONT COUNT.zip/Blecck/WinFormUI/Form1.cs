﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fiveHourButton_Click(object sender, EventArgs e)
        {
            //Take user speed from the text box and multiply by 5 then display to user
            MessageBox.Show($"You traveled {(int.Parse(speedTextBox.Text) * 5).ToString()} miles on this trip.");
            speedTextBox.Clear();
        }

        private void eightHourButton_Click(object sender, EventArgs e)
        {
            //Take user speed from the text box and multiply by 8 then display to user
            MessageBox.Show($"You traveled {(int.Parse(speedTextBox.Text) * 8).ToString()} miles on this trip.");
            speedTextBox.Clear();
        }

        private void twelveHourButton_Click(object sender, EventArgs e)
        {
            //Take user speed from the text box and multiply by 12 then display to user
            MessageBox.Show($"You traveled {(int.Parse(speedTextBox.Text) * 12).ToString()} miles on this trip.");
            speedTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
