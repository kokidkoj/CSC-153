﻿
namespace WinFormUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.speedTextBox = new System.Windows.Forms.TextBox();
            this.fiveHourButton = new System.Windows.Forms.Button();
            this.eightHourButton = new System.Windows.Forms.Button();
            this.twelveHourButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(12, 9);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(247, 13);
            this.descriptionLabel.TabIndex = 0;
            this.descriptionLabel.Text = "Calculate how far you traveled after entering speed";
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(15, 37);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(128, 13);
            this.speedLabel.TabIndex = 1;
            this.speedLabel.Text = "Enter your speed in MPH:";
            // 
            // speedTextBox
            // 
            this.speedTextBox.Location = new System.Drawing.Point(18, 54);
            this.speedTextBox.Name = "speedTextBox";
            this.speedTextBox.Size = new System.Drawing.Size(100, 20);
            this.speedTextBox.TabIndex = 2;
            // 
            // fiveHourButton
            // 
            this.fiveHourButton.Location = new System.Drawing.Point(18, 89);
            this.fiveHourButton.Name = "fiveHourButton";
            this.fiveHourButton.Size = new System.Drawing.Size(75, 23);
            this.fiveHourButton.TabIndex = 3;
            this.fiveHourButton.Text = "5 Hours";
            this.fiveHourButton.UseVisualStyleBackColor = true;
            this.fiveHourButton.Click += new System.EventHandler(this.fiveHourButton_Click);
            // 
            // eightHourButton
            // 
            this.eightHourButton.Location = new System.Drawing.Point(99, 89);
            this.eightHourButton.Name = "eightHourButton";
            this.eightHourButton.Size = new System.Drawing.Size(75, 23);
            this.eightHourButton.TabIndex = 4;
            this.eightHourButton.Text = "8 Hours";
            this.eightHourButton.UseVisualStyleBackColor = true;
            this.eightHourButton.Click += new System.EventHandler(this.eightHourButton_Click);
            // 
            // twelveHourButton
            // 
            this.twelveHourButton.Location = new System.Drawing.Point(180, 89);
            this.twelveHourButton.Name = "twelveHourButton";
            this.twelveHourButton.Size = new System.Drawing.Size(75, 23);
            this.twelveHourButton.TabIndex = 5;
            this.twelveHourButton.Text = "12 Hours";
            this.twelveHourButton.UseVisualStyleBackColor = true;
            this.twelveHourButton.Click += new System.EventHandler(this.twelveHourButton_Click);
            // 
            // clearButton
            // 
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(180, 199);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 263);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.twelveHourButton);
            this.Controls.Add(this.eightHourButton);
            this.Controls.Add(this.fiveHourButton);
            this.Controls.Add(this.speedTextBox);
            this.Controls.Add(this.speedLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Name = "Form1";
            this.Text = "Distance Traveled";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.TextBox speedTextBox;
        private System.Windows.Forms.Button fiveHourButton;
        private System.Windows.Forms.Button eightHourButton;
        private System.Windows.Forms.Button twelveHourButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

