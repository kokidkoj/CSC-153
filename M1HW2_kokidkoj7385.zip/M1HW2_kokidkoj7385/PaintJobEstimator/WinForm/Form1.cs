﻿/**
* 1/30/2029
* CSC 153
* Jonathan Kokidko
* This program allows you to get an estimate on the cost of a paint job
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {

        decimal ratio;
        decimal numGallons;
        decimal laborHours;
        decimal totalPaintCost;
        decimal laborCharge;
        decimal total;
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            ratio = decimal.Parse(sqrNeededTextBox.Text)/115;
            numGallons = Math.Ceiling(1 * ratio);
            laborHours = Math.Ceiling(8 * ratio);
            totalPaintCost = numGallons * decimal.Parse(paintCostTextBox.Text);
            laborCharge = 20 * laborHours;
            total = totalPaintCost + laborCharge;
            numPaintGallonLabel.Text = numGallons.ToString("n0");
            numTotalPaintCostLabel.Text = totalPaintCost.ToString("c2");
            numLaborHourLabel.Text = laborHours.ToString("n0");
            numLaborCostLabel.Text = laborCharge.ToString("c2");
            numTotalLabel.Text = total.ToString("c2");
        }

    }
}
