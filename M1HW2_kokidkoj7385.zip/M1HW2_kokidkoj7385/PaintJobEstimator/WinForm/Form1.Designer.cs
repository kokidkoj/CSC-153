﻿
namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.sqrNeededLabel = new System.Windows.Forms.Label();
            this.costOfPaintLabel = new System.Windows.Forms.Label();
            this.sqrNeededTextBox = new System.Windows.Forms.TextBox();
            this.paintCostTextBox = new System.Windows.Forms.TextBox();
            this.gallonsPaintLabel = new System.Windows.Forms.Label();
            this.totalPaintCostLabel = new System.Windows.Forms.Label();
            this.laborHourLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.numTotalLabel = new System.Windows.Forms.Label();
            this.numLaborCostLabel = new System.Windows.Forms.Label();
            this.numLaborHourLabel = new System.Windows.Forms.Label();
            this.numTotalPaintCostLabel = new System.Windows.Forms.Label();
            this.numPaintGallonLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(93, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(114, 17);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Paint Job Pricing";
            // 
            // sqrNeededLabel
            // 
            this.sqrNeededLabel.AutoSize = true;
            this.sqrNeededLabel.Location = new System.Drawing.Point(12, 41);
            this.sqrNeededLabel.Name = "sqrNeededLabel";
            this.sqrNeededLabel.Size = new System.Drawing.Size(142, 17);
            this.sqrNeededLabel.TabIndex = 1;
            this.sqrNeededLabel.Text = "Square Feet to Paint:";
            // 
            // costOfPaintLabel
            // 
            this.costOfPaintLabel.AutoSize = true;
            this.costOfPaintLabel.Location = new System.Drawing.Point(12, 70);
            this.costOfPaintLabel.Name = "costOfPaintLabel";
            this.costOfPaintLabel.Size = new System.Drawing.Size(162, 17);
            this.costOfPaintLabel.TabIndex = 2;
            this.costOfPaintLabel.Text = "Cost of Paint per Gallon:";
            // 
            // sqrNeededTextBox
            // 
            this.sqrNeededTextBox.Location = new System.Drawing.Point(206, 36);
            this.sqrNeededTextBox.Name = "sqrNeededTextBox";
            this.sqrNeededTextBox.Size = new System.Drawing.Size(100, 22);
            this.sqrNeededTextBox.TabIndex = 3;
            // 
            // paintCostTextBox
            // 
            this.paintCostTextBox.Location = new System.Drawing.Point(206, 65);
            this.paintCostTextBox.Name = "paintCostTextBox";
            this.paintCostTextBox.Size = new System.Drawing.Size(100, 22);
            this.paintCostTextBox.TabIndex = 4;
            // 
            // gallonsPaintLabel
            // 
            this.gallonsPaintLabel.AutoSize = true;
            this.gallonsPaintLabel.Location = new System.Drawing.Point(13, 173);
            this.gallonsPaintLabel.Name = "gallonsPaintLabel";
            this.gallonsPaintLabel.Size = new System.Drawing.Size(166, 17);
            this.gallonsPaintLabel.TabIndex = 6;
            this.gallonsPaintLabel.Text = "Gallons of Paint Needed:";
            // 
            // totalPaintCostLabel
            // 
            this.totalPaintCostLabel.AutoSize = true;
            this.totalPaintCostLabel.Location = new System.Drawing.Point(13, 194);
            this.totalPaintCostLabel.Name = "totalPaintCostLabel";
            this.totalPaintCostLabel.Size = new System.Drawing.Size(112, 17);
            this.totalPaintCostLabel.TabIndex = 7;
            this.totalPaintCostLabel.Text = "Total Paint Cost:";
            // 
            // laborHourLabel
            // 
            this.laborHourLabel.AutoSize = true;
            this.laborHourLabel.Location = new System.Drawing.Point(13, 215);
            this.laborHourLabel.Name = "laborHourLabel";
            this.laborHourLabel.Size = new System.Drawing.Size(161, 17);
            this.laborHourLabel.TabIndex = 8;
            this.laborHourLabel.Text = "Number of Labor Hours:";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.AutoSize = true;
            this.laborCostLabel.Location = new System.Drawing.Point(13, 236);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(117, 17);
            this.laborCostLabel.TabIndex = 9;
            this.laborCostLabel.Text = "Total Labor Cost:";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(13, 291);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(80, 17);
            this.totalLabel.TabIndex = 10;
            this.totalLabel.Text = "Total Price:";
            // 
            // numTotalLabel
            // 
            this.numTotalLabel.AutoSize = true;
            this.numTotalLabel.Location = new System.Drawing.Point(206, 291);
            this.numTotalLabel.Name = "numTotalLabel";
            this.numTotalLabel.Size = new System.Drawing.Size(44, 17);
            this.numTotalLabel.TabIndex = 11;
            this.numTotalLabel.Text = "$0.00";
            // 
            // numLaborCostLabel
            // 
            this.numLaborCostLabel.AutoSize = true;
            this.numLaborCostLabel.Location = new System.Drawing.Point(206, 236);
            this.numLaborCostLabel.Name = "numLaborCostLabel";
            this.numLaborCostLabel.Size = new System.Drawing.Size(44, 17);
            this.numLaborCostLabel.TabIndex = 12;
            this.numLaborCostLabel.Text = "$0.00";
            // 
            // numLaborHourLabel
            // 
            this.numLaborHourLabel.AutoSize = true;
            this.numLaborHourLabel.Location = new System.Drawing.Point(206, 215);
            this.numLaborHourLabel.Name = "numLaborHourLabel";
            this.numLaborHourLabel.Size = new System.Drawing.Size(16, 17);
            this.numLaborHourLabel.TabIndex = 13;
            this.numLaborHourLabel.Text = "0";
            // 
            // numTotalPaintCostLabel
            // 
            this.numTotalPaintCostLabel.AutoSize = true;
            this.numTotalPaintCostLabel.Location = new System.Drawing.Point(206, 194);
            this.numTotalPaintCostLabel.Name = "numTotalPaintCostLabel";
            this.numTotalPaintCostLabel.Size = new System.Drawing.Size(44, 17);
            this.numTotalPaintCostLabel.TabIndex = 14;
            this.numTotalPaintCostLabel.Text = "$0.00";
            // 
            // numPaintGallonLabel
            // 
            this.numPaintGallonLabel.AutoSize = true;
            this.numPaintGallonLabel.Location = new System.Drawing.Point(206, 173);
            this.numPaintGallonLabel.Name = "numPaintGallonLabel";
            this.numPaintGallonLabel.Size = new System.Drawing.Size(16, 17);
            this.numPaintGallonLabel.TabIndex = 15;
            this.numPaintGallonLabel.Text = "0";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(96, 115);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(118, 23);
            this.calculateButton.TabIndex = 17;
            this.calculateButton.Text = "Calculate Cost";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 334);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.numPaintGallonLabel);
            this.Controls.Add(this.numTotalPaintCostLabel);
            this.Controls.Add(this.numLaborHourLabel);
            this.Controls.Add(this.numLaborCostLabel);
            this.Controls.Add(this.numTotalLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.laborHourLabel);
            this.Controls.Add(this.totalPaintCostLabel);
            this.Controls.Add(this.gallonsPaintLabel);
            this.Controls.Add(this.paintCostTextBox);
            this.Controls.Add(this.sqrNeededTextBox);
            this.Controls.Add(this.costOfPaintLabel);
            this.Controls.Add(this.sqrNeededLabel);
            this.Controls.Add(this.titleLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label sqrNeededLabel;
        private System.Windows.Forms.Label costOfPaintLabel;
        private System.Windows.Forms.TextBox sqrNeededTextBox;
        private System.Windows.Forms.TextBox paintCostTextBox;
        private System.Windows.Forms.Label gallonsPaintLabel;
        private System.Windows.Forms.Label totalPaintCostLabel;
        private System.Windows.Forms.Label laborHourLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label numTotalLabel;
        private System.Windows.Forms.Label numLaborCostLabel;
        private System.Windows.Forms.Label numLaborHourLabel;
        private System.Windows.Forms.Label numTotalPaintCostLabel;
        private System.Windows.Forms.Label numPaintGallonLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

