﻿
namespace WinFormUI
{
    partial class propertyTaxCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleExplanationLabel = new System.Windows.Forms.Label();
            this.enterPropValLabel = new System.Windows.Forms.Label();
            this.propertyValueTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleExplanationLabel
            // 
            this.titleExplanationLabel.AutoSize = true;
            this.titleExplanationLabel.Location = new System.Drawing.Point(95, 19);
            this.titleExplanationLabel.Name = "titleExplanationLabel";
            this.titleExplanationLabel.Size = new System.Drawing.Size(185, 17);
            this.titleExplanationLabel.TabIndex = 0;
            this.titleExplanationLabel.Text = "Calculate Your Property Tax";
            // 
            // enterPropValLabel
            // 
            this.enterPropValLabel.AutoSize = true;
            this.enterPropValLabel.Location = new System.Drawing.Point(31, 64);
            this.enterPropValLabel.Name = "enterPropValLabel";
            this.enterPropValLabel.Size = new System.Drawing.Size(144, 17);
            this.enterPropValLabel.TabIndex = 1;
            this.enterPropValLabel.Text = "Enter Property Value:";
            // 
            // propertyValueTextBox
            // 
            this.propertyValueTextBox.Location = new System.Drawing.Point(243, 61);
            this.propertyValueTextBox.Name = "propertyValueTextBox";
            this.propertyValueTextBox.Size = new System.Drawing.Size(100, 22);
            this.propertyValueTextBox.TabIndex = 2;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(145, 125);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(106, 23);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calculate Tax";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // propertyTaxCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 182);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.propertyValueTextBox);
            this.Controls.Add(this.enterPropValLabel);
            this.Controls.Add(this.titleExplanationLabel);
            this.Name = "propertyTaxCalc";
            this.Text = "Property Tax Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleExplanationLabel;
        private System.Windows.Forms.Label enterPropValLabel;
        private System.Windows.Forms.TextBox propertyValueTextBox;
        private System.Windows.Forms.Button calculateButton;
    }
}

