﻿/**
* 2/1/2023
* CSC 153
* Jonathan Kokidko
* This propgram allows you to calculate your property tax
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class propertyTaxCalc : Form
    {
        public propertyTaxCalc()
        {
            InitializeComponent();
        }
        
        private void calculateButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show((decimal.Parse(propertyValueTextBox.Text) / 100 * 0.64m).ToString("c2"));
            //take user input and divide it by 100 * .64 ($0.64 for every $100 is property tax)
            propertyValueTextBox.Clear();
            //clear text box to let user enter another value
        }
    }
}
