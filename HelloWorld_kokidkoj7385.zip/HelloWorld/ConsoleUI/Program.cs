﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Jonathan Kokidko");
            Console.WriteLine("From this class I wish to gain at least the fundamental knowledge for C# as I'm aiming to learn as many programming ");
            Console.WriteLine("languages as I can.");
            Console.WriteLine("The programming classes I have taken are Intro to Java, Java, CTI-110, and Python.");
            Console.WriteLine("I have learned everything listed.");
            Console.ReadLine();
        }
    }
}
